﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    public class Project
    {
        public int ProjectID { get; set; }

        public string ProjectName { get; set; }

        public string Technology { get; set; }
    }
}
