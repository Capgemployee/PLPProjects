create database Training_18Jan2017_Talwade

--###################################################

USE [Training_18Jan2017_Talwade]
GO

--###################################################
CREATE SCHEMA [MySchemaEMS]
GO

--###################### TABLES #####################
CREATE TABLE [MySchemaEMS].EmployeeDetails
(
EmpID INT IDENTITY(121100,1),
EmpFName VARCHAR(20) NOT NULL,
EmpLName VARCHAR(20) NOT NULL,
EmpGender CHAR NOT NULL
CONSTRAINT CHK_Gender CHECK (EmpGender='M' OR EmpGender='F'),
EmpAge INT NOT NULL
CONSTRAINT CHK_Age CHECK(EmpAge>=18 AND EmpAge<=60),
EmpDesignation VARCHAR(20) NOT NULL,
EmpSkills VARCHAR(30) NOT NULL,
EmpSalary NUMERIC(10,2) NOT NULL,
EmpAddress VARCHAR(50) NOT NULL,
EmpDOB Date NOT NULL,
EmpDOJ Datetime NOT NULL,
EmpContactNo CHAR(10) NOT NULL,
EmpEmailId VARCHAR(30) NOT NULL,
UserID VARCHAR(30) PRIMARY KEY
)

CREATE TABLE [MySchemaEMS].LoginDetails(
UserID VARCHAR(30) FOREIGN KEY REFERENCES [MySchemaEMS].EmployeeDetails(UserID),
UserPswd VARCHAR(30) NOT NULL,
UserType VARCHAR(20) NOT NULL
)


CREATE TABLE [MySchemaEMS].ProjectDetails(
EmpID INT FOREIGN KEY REFERENCES  [MySchemaEMS].EmployeeDetails(EmpID),
ProjectID INT PRIMARY KEY,
ProjectName VARCHAR(40) NOT NULL,
ProjectTechnology VARCHAR(50) NOT NULL,
)

--################# SELECT COMMAND ###########################

SELECT * FROM  [MySchemaEMS].EmployeeDetails

SELECT * FROM  [MySchemaEMS].LoginDetails

SELECT * FROM  [MySchemaEMS].ProjectDetails

--################# DROP COMMAND ##############################

DROP TABLE [MySchemaEMS].EmployeeDetails

DROP TABLE [MySchemaEMS].LoginDetails

DROP TABLE [MySchemaEMS].ProjectDetails

--################# INSERT COMMAND ##############################

INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Shruti','Hassan','F',22,'Developer','DOT.NET',200000,'Nagpur','03/24/2017','01/18/2017',9870657483,'shruti@gmail.com')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Shru','Hassan','F',22,'Developer','TESTING',200000,'Mumbai','03/24/2017','01/18/2017',9870657483,'shru@gmail.com')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Shrutiiii','Hassan','F',22,'Developer','JAVA',200000,'Pune','04/28/2017','01/18/2017',9870657483,'shrutiiii@gmail.com')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Karan','Johar','M',22,'Manager','JAVA',200000,'Pune','04/25/2017','01/18/2017',9870657483,'karan@gmail.com')
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES('Karan','Johar','M',22,'HR','JAVA',200000,'Pune','04/25/2017','01/18/2017',9870657483,'karan@gmail.com')


INSERT INTO [MySchemaEMS].LoginDetails
VALUES('manager','manager123','manager')
INSERT INTO [MySchemaEMS].LoginDetails
VALUES('admin','admin123','admin')
INSERT INTO [MySchemaEMS].LoginDetails
VALUES('hr','hr123','hr')
INSERT INTO [MySchemaEMS].LoginDetails
VALUES('employee','employee123','employee')

INSERT INTO [MySchemaEMS].ProjectDetails
VALUES(121105,1001,'EMS','JAVA')
INSERT INTO [MySchemaEMS].ProjectDetails
VALUES(121106,1002,'HMS','DOTNET')
--INSERT INTO [MySchemaEMS].ProjectDetails
--VALUES('1003','GMS','JAVA')
--INSERT INTO [MySchemaEMS].ProjectDetails
--VALUES('1004','BPS','JAVA')

--############# STORED PROCEDURE OF EMPLOYEE #############################
CREATE PROCEDURE [MySchemaEMS].DisplayProjectDetails 
AS
SELECT * FROM [MySchemaEMS].ProjectDetails

ALTER PROCEDURE [MySchemaEMS].usp_EmployeeInfo
(
@EmpID INT
)
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails
WHERE EmpID=@EmpID

ALTER PROCEDURE [MySchemaEMS].usp_UpdateEmployeeInfo
(
	@EmpID INT,
	--@EmpDeptID INT OUT,
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	--@EmpGender CHAR OUT,
	@EmpAge INT,
	--@EmpDesignation VARCHAR(20) OUT,
	@EmpSkills VARCHAR(30),
	--@EmpSalary NUMERIC(10,2) OUT,
	@EmpAddress VARCHAR(50),
	@EmpDOB Date,
	--@EmpDOJ Datetime OUT,
	@EmpContactNo CHAR(10),
	@EmpEmailId VARCHAR(30)	
)
AS
UPDATE [MySchemaEMS].EmployeeDetails 
SET EmpFName=@EmpFName,EmpLName=@EmpLName,EmpAge=@EmpAge,
@EmpSkills=EmpSkills,EmpAddress=@EmpAddress,EmpDOB=@EmpDOB,
EmpContactNo=@EmpContactNo,EmpEmailId=@EmpEmailId
WHERE EmpID=@EmpID

EXEC [MySchemaEMS].usp_UpdateEmployeeInfo 121105,'Shrutii','Jamgade',21,'java','mumbai','05/05/1998',9874563214,'shruti@gmail.com'

--############# STORED PROCEDURE OF HR #############################
ALTER PROCEDURE [MySchemaEMS].usp_DisplayAllEmployeeDetails
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails

ALTER PROCEDURE [MySchemaEMS].usp_RetrieveAllEmployeeDetails
(
	@DeptName VARCHAR(20)
)
AS
SELECT  emp.EmpID,emp.EmpFName,emp.EmpLName,emp.EmpGender,emp.EmpAge,emp.EmpSkills,emp.EmpAddress,emp.EmpDOB,
emp.EmpDOJ,emp.EmpContactNo,emp.EmpEmailId,dept.DeptName
FROM [MySchemaEMS].EmployeeDetails emp
INNER JOIN [MySchemaEMS].DeptDetails dept
ON emp.DeptID=dept.DeptID
WHERE DeptName=@DeptName


ALTER PROCEDURE [MySchemaEMS].usp_AddEmployeeRecord
(
	@DeptID INT,
	@EmpFName VARCHAR(20),
	@EmpLName VARCHAR(20),
	@EmpGender CHAR,
	@EmpAge INT,
	@EmpSkills VARCHAR(30),
	@EmpDesignation VARCHAR(20),
	@EmpSalary NUMERIC(10,2),
	@EmpAddress VARCHAR(50),
	@EmpDOB Datetime,
	@EmpDOJ Datetime,
	@EmpContactNo NUMERIC(10),
	@EmpEmailId VARCHAR(30)	
)
AS
INSERT INTO [MySchemaEMS].EmployeeDetails
VALUES(@DeptID,@EmpFName,@EmpLName,@EmpGender,@EmpAge,@EmpSkills,@EmpDesignation,@EmpSalary,
@EmpAddress,@EmpDOB,@EmpDOJ,@EmpContactNo,@EmpEmailId)

EXEC [MySchemaEMS].usp_AddEmployeeRecord 112,'Shubham','Agrawal','M',22,'Java','Developer',20000,'Mumbai',
'03/24/2017','01/18/2017',9870657483,'shu@gmail.com'

ALTER PROCEDURE [MySchemaEMS].usp_DeleteEmployeeRecord
(
	@EmpID INT
)
AS
DELETE FROM [MySchemaEMS].EmployeeDetails
WHERE  EmpID=@EmpID

ALTER PROCEDURE [MySchemaEMS].usp_HRInfo
(
@EmpID INT
)
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails
WHERE EmpID=@EmpID


----############# STORED PROCEDURE OF ADMIN #############################
--ALTER PROCEDURE [MySchemaEMS].usp_AddRecord
--(
--	@EmpID INT OUT,
--	@DeptID INT,
--	@EmpFName VARCHAR(20),
--	@EmpLName VARCHAR(20),
--	@EmpGender CHAR,
--	@EmpAge INT,
--	@EmpSkills VARCHAR(30),
--	@EmpDesignation VARCHAR(20),
--	@EmpSalary NUMERIC(10,2),
--	@EmpAddress VARCHAR(50),
--	@EmpDOB Date,
--	@EmpDOJ Datetime,
--	@EmpContactNo NUMERIC(10),
--	@EmpEmailId VARCHAR(30)	
--)
--AS
--INSERT INTO [MySchemaEMS].EmployeeDetails
--VALUES(@DeptID,@EmpFName,@EmpLName,@EmpGender,@EmpAge,@EmpSkills,@EmpDesignation,@EmpSalary,
--@EmpAddress,@EmpDOB,@EmpDOJ,@EmpContactNo,@EmpEmailId)

--ALTER PROCEDURE [MySchemaEMS].usp_DeleteHRRecord
--(
--	@EmpID INT
--)
--AS
--DELETE FROM [MySchemaEMS].EmployeeDetails
--WHERE  EmpID=@EmpID

--ALTER PROCEDURE [MySchemaEMS].usp_UpdateHRRecord
--(
--	@EmpID INT,
--	@DeptID INT,
--	@EmpFName VARCHAR(20),
--	@EmpLName VARCHAR(20),
--	@EmpGender CHAR,
--	@EmpAge INT,
--	@EmpSkills VARCHAR(30),
--	@EmpDesignation VARCHAR(20),
--	@EmpSalary NUMERIC(10,2),
--	@EmpAddress VARCHAR(50),
--	@EmpDOB Date,
--	@EmpDOJ Datetime,
--	@EmpContactNo NUMERIC(10),
--	@EmpEmailId VARCHAR(30)	
--)
--AS
--UPDATE [MySchemaEMS].EmployeeDetails 
--SET DeptID=@DeptID,EmpFName=@EmpFName,EmpLName=@EmpLName,EmpGender=@EmpGender,EmpAge=@EmpAge,
--EmpSkills=@EmpSkills,EmpDesignation=@EmpDesignation,EmpSalary=@EmpSalary,EmpAddress=@EmpAddress,
--EmpDOB=@EmpDOB,EmpDOJ=@EmpDOJ,EmpContactNo=@EmpContactNo,EmpEmailId=@EmpEmailId
--WHERE EmpID=@EmpID

--ALTER PROCEDURE [MySchemaEMS].usp_AdminInfo
--(
--@EmpID INT
--)
--AS
--SELECT * FROM [MySchemaEMS].EmployeeDetails
--WHERE EmpID=@EmpID

--ALTER PROCEDURE [MySchemaEMS].usp_DisplayAllEmployeeRecord
--AS
--SELECT * FROM [MySchemaEMS].EmployeeDetails


CREATE PROC [MySchemaEMS].usp_ValidateLoginDetails
(
	@UserID	VARCHAR(30),
	@UserPswd VARCHAR(30),
	@UserType VARCHAR(20) 
)
AS
BEGIN
	SELECT * FROM LoginDetails 
	WHERE UserID = @UserID AND UserPswd = @UserPswd AND UserType=@UserType
END

--CREATE PROCEDURE [MySchemaEMS].usp_PasswordValidate
--(
--	@SecurityQuestion VARCHAR(90),
--	@SecurityAnswer VARCHAR(90)
--)
--AS
--BEGIN
--	SELECT 1 FROM [MySchemaEMS].ValidateChangePassword 
--	WHERE SecurityQuestion = @SecurityQuestion AND SecurityAnswer = @SecurityAnswer
--END


--################### EXECUTE PROCEDURE ###################

ALTER PROCEDURE [MySchemaEMS].usp_EmployeeBirthday
AS
SELECT  EmpID, DeptID, EmpFName, EmpLName, EmpAddress, EmpDOB, EmpDOJ, EmpContactNo, EmpEmailId
FROM [MySchemaEMS].EmployeeDetails
WHERE DATEPART( month, EmpDOB)=DATEPART( month, GETDATE());

EXEC [MySchemaEMS].usp_EmployeeBirthday 

--##### PROCEDURE FOR LOGIN DETAILS#######
ALTER PROCEDURE [MySchemaEMS].usp_DisplayAllLoginDetails
AS
SELECT * FROM [MySchemaEMS].LoginDetails



EXEC [MySchemaEMS].usp_RetrieveAllEmployeeDetails 'HR'

EXEC [MySchemaEMS].usp_AddEmployeeRecord
112,'Vinit','Surya','M',22,'HR','Java',13246,'Mumbai','04/05/2001','04/04/2017',9878675843,'vinit@gmaqil.com'

EXEC [MySchemaEMS].usp_EmployeeInfo 121100

EXEC [MySchemaEMS].usp_ValidateLoginDetails 'hr', 'hr123', 'hr'


--########## PROCEDURE OF MANAGER #################

CREATE PROCEDURE [MySchemaEMS].usp_SearchbySkills
(
@EmpSkills VARCHAR(30)
)
AS
SELECT * FROM [MySchemaEMS].EmployeeDetails
WHERE EmpSkills=@EmpSkills


EXEC [MySchemaEMS].usp_SearchbySkills 'JAVA'

CREATE PROCEDURE [MySchemaEMS].usp_AllocateProject
(
	@EmpID INT,
	@ProjectID INT,
	@ProjectName VARCHAR(40),
	@ProjectTechnology VARCHAR(50)
)
AS
INSERT INTO [MySchemaEMS].ProjectAllocationDetails
VALUES(@EmpID,@ProjectID,@ProjectName,@ProjectTechnology)
